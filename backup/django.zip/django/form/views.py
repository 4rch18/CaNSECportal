# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponseRedirect

from .models import Indicator, SubIndicator
from .forms import testSubindicatorForm

# Create your views here.

def index(request):
    indicator_list = Indicator.objects.all()
    subindicator_list = SubIndicator.objects.all()

    if request.method == 'POST':
        form = testSubindicatorForm(request.POST)
        if form.is_valid():
            print form.cleaned_data
            print type(form.cleaned_data)
            # store in database?

            # pass dict to script function / script reads data from database

            return HttpResponseRedirect('/form/')
    else:
        form = testSubindicatorForm()
        print form
        print type(form)

    context = {
        'indicator_list': indicator_list,
        'subindicator_list': subindicator_list,
        'form': form,
    }

    return render(request, 'form/index.html', context)

def detail(request, indicator_id):
    try:
        indicator = Indicator.objects.get(pk=indicator_id)
    except Indicator.DoesNotExist:
        raise Http404("Question does not exist")
    return render(request, 'form/detail.html', {'indicator': indicator})