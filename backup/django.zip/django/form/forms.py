from django import forms
from .models import Indicator, SubIndicator

class testSubindicatorForm(forms.Form):

    subi_0 = forms.BooleanField(required=False)
    subi_1 = forms.DecimalField(decimal_places=2)
    subi_2 = forms.DecimalField(decimal_places=0)
    subi_3 = forms.DecimalField(decimal_places=2, min_value=0.00, max_value=100.00)

    '''
    subi_list = SubIndicator.objects.all()
    temp_forms = [None] * len(subi_list)

    for i in range(0, len(subi_list)):
        if subi_list[i].datatype == 'B':
            temp_forms[i] = forms.BooleanField(required=False)
        elif subi_list[i].datatype == 'D':
            temp_forms[i] = forms.DecimalField(decimal_places=2)
        elif subi_list[i].datatype == 'I':
            temp_forms[i] = forms.DecimalField(decimal_places=0)
        elif subi_list[i].datatype == 'P':
            temp_forms[i] = forms.DecimalField(decimal_places=2, min_value=0.00, max_value=100.00)
    '''


''' Idea is to create a form for all the subindicators using a function, not hardcoding it for all the subindicators
class SubIndicatorFormRadio(forms.Form):
    input_data = forms.BooleanField()

class SubIndicatorFormDecimal(forms.Form):
    input_data = forms.DecimalField()

class CreateForm():
    subindicator_list = SubIndicator.objects.all()

    for elem in subindicator_list:
        subindicator_name = elem.subindicator_text
        if elem.datatype == 'B':
            subindicator_input =

'''