default_app_config = 'form.apps.FormConfig'
    # Reference= https://stackoverflow.com/questions/24319558/how-to-resolve-django-core-exceptions-improperlyconfigured-application-labels