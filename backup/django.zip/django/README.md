# CaNSECportal
A portal for CaNSEC framework for assessment of educational institutes
